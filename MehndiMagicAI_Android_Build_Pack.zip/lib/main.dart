import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';

void main() => runApp(const MehndiMagicApp());

const maroon = Color(0xFF6F1728);
const cream = Color(0xFFFFF7E9);
const gold = Color(0xFFC49A45);

class MehndiMagicApp extends StatelessWidget {
  const MehndiMagicApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mehndi Magic AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: maroon),
        appBarTheme: const AppBarTheme(backgroundColor: maroon, foregroundColor: Colors.white),
      ),
      home: const HomeScreen(),
    );
  }
}

class DesignItem {
  final String title, category, symbol, detail;
  const DesignItem(this.title, this.category, this.symbol, this.detail);
}

const designs = <DesignItem>[
  DesignItem('Bridal Mandala', 'दुल्हन', '❋', 'हथेली के बीच में बड़ा गोल मंडला और बारीक फूल।'),
  DesignItem('Arabic Trail', 'अरबी', '❦', 'पत्तियों और फूलों की तिरछी बेल वाला डिज़ाइन।'),
  DesignItem('Simple Fingers', 'उँगलियाँ', '✿', 'उँगलियों और हथेली के किनारे के लिए सरल पैटर्न।'),
  DesignItem('Full Hand Floral', 'फुल हैंड', '❀', 'फूलों, जालियों और पत्तियों से भरा पारंपरिक पैटर्न।'),
  DesignItem('Back Hand Rose', 'बैक हैंड', '✾', 'हाथ के पीछे गुलाब और बेलों से प्रेरित डिज़ाइन।'),
  DesignItem('Minimal Mandala', 'सिंपल', '✺', 'कम समय में बनाने योग्य साफ-सुथरा मंडला।'),
  DesignItem('Rajasthani Motif', 'राजस्थानी', '❁', 'पारंपरिक बारीक आकृतियों और ज्यामितीय पैटर्न का मेल।'),
  DesignItem('Feet Floral', 'पैर', '❃', 'पैरों और टखनों के लिए फूलों वाली बेल।'),
];

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String query = '';
  String category = 'सभी';
  Set<String> favorites = {};
  File? handPhoto;
  final picker = ImagePicker();
  final categories = const ['सभी', 'दुल्हन', 'अरबी', 'उँगलियाँ', 'फुल हैंड', 'बैक हैंड', 'सिंपल', 'राजस्थानी', 'पैर'];

  @override
  void initState() { super.initState(); _loadFavorites(); }

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) setState(() => favorites = (prefs.getStringList('favorites') ?? []).toSet());
  }

  Future<void> _toggleFavorite(String title) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      if (!favorites.add(title)) favorites.remove(title);
    });
    await prefs.setStringList('favorites', favorites.toList());
  }

  Future<void> _pickPhoto() async {
    try {
      final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
      if (file != null && mounted) setState(() => handPhoto = File(file.path));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('फोटो नहीं खुल सकी। कृपया दोबारा कोशिश करें।')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final filtered = designs.where((d) =>
      (category == 'सभी' || d.category == category) &&
      ('${d.title} ${d.category} ${d.detail}'.toLowerCase().contains(query.toLowerCase()))).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('🌿 Mehndi Magic AI', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [IconButton(tooltip: 'पसंदीदा', onPressed: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => FavoritesScreen(favorites: favorites, onToggle: _toggleFavorite))),
          icon: const Icon(Icons.favorite))],
      ),
      body: CustomScrollView(slivers: [
        SliverToBoxAdapter(child: Container(
          margin: const EdgeInsets.all(16), padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [maroon, Color(0xFF9B3A45)]),
            borderRadius: BorderRadius.circular(22)),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('आपकी मेहंदी, आपकी पसंद ✨', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('डिज़ाइन देखें • पसंदीदा सेव करें • अपनी फोटो पर ट्राई करें',
              style: TextStyle(color: Colors.white, height: 1.4)),
          ]),
        )),
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 16),
          child: TextField(
            decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'डिज़ाइन खोजें…',
              filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)),
            onChanged: (v) => setState(() => query = v),
          ))),
        SliverToBoxAdapter(child: SizedBox(height: 58, child: ListView.separated(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          scrollDirection: Axis.horizontal, itemCount: categories.length,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (_, i) => ChoiceChip(label: Text(categories[i]), selected: category == categories[i],
            onSelected: (_) => setState(() => category = categories[i]),
            selectedColor: const Color(0xFFE7C9A2)),
        ))),
        SliverPadding(padding: const EdgeInsets.fromLTRB(16, 2, 16, 12),
          sliver: SliverGrid(
            delegate: SliverChildBuilderDelegate((context, i) {
              final d = filtered[i];
              return InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) =>
                  DesignDetailScreen(item: d, isFavorite: favorites.contains(d.title), onToggle: () => _toggleFavorite(d.title)))),
                child: Container(
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: const Color(0xFFE9D8C3))),
                  child: Column(children: [
                    Expanded(child: Container(width: double.infinity,
                      decoration: BoxDecoration(borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
                        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
                          colors: [Color(0xFFFFE8C7), Color(0xFFF5D5C0)])),
                      child: Stack(children: [
                        Center(child: Text(d.symbol, style: const TextStyle(fontSize: 70, color: maroon))),
                        Positioned(right: 5, top: 5, child: IconButton(
                          onPressed: () => _toggleFavorite(d.title),
                          icon: Icon(favorites.contains(d.title) ? Icons.favorite : Icons.favorite_border,
                            color: favorites.contains(d.title) ? maroon : Colors.brown)))
                      ]))),
                    Padding(padding: const EdgeInsets.all(9), child: Column(children: [
                      Text(d.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                      Text(d.category, style: const TextStyle(color: Colors.brown, fontSize: 12)),
                    ]))
                  ]),
                ),
              );
            }, childCount: filtered.length),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .78),
          )),
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          child: Card(color: const Color(0xFFFFE8C7), child: Padding(padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('📸 अपनी फोटो पर डिज़ाइन ट्राई करें', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              const Text('यह शुरुआती संस्करण फोटो चुनने और उस पर डेमो पैटर्न दिखाने की सुविधा देता है।'),
              const SizedBox(height: 12),
              FilledButton.icon(onPressed: _pickPhoto, icon: const Icon(Icons.add_a_photo), label: const Text('हाथ की फोटो चुनें')),
              if (handPhoto != null) ...[
                const SizedBox(height: 12),
                ClipRRect(borderRadius: BorderRadius.circular(12), child: Stack(alignment: Alignment.center, children: [
                  Image.file(handPhoto!, height: 260, width: double.infinity, fit: BoxFit.contain),
                  IgnorePointer(child: Opacity(opacity: .65, child: Text('❋', style: TextStyle(fontSize: 110, color: maroon.withValues(alpha: .9))))),
                ])),
                const Text('डेमो ओवरले: यह वास्तविक hand-tracking नहीं है।', style: TextStyle(fontSize: 12, color: Colors.brown)),
                TextButton.icon(onPressed: () => Share.shareXFiles([XFile(handPhoto!.path)], text: 'Mehndi Magic AI - मेरी फोटो'),
                  icon: const Icon(Icons.share), label: const Text('फोटो शेयर करें')),
              ]
            ])))),
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.all(16),
          child: Text('Mehndi Magic AI • शुरुआती MVP', textAlign: TextAlign.center,
            style: TextStyle(color: Colors.brown.shade400, fontSize: 12))))
      ]),
    );
  }
}

class DesignDetailScreen extends StatelessWidget {
  final DesignItem item;
  final bool isFavorite;
  final VoidCallback onToggle;
  const DesignDetailScreen({super.key, required this.item, required this.isFavorite, required this.onToggle});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(item.title)),
    body: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Expanded(child: Container(decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFFFFE8C7), Color(0xFFF5D5C0)]),
        borderRadius: BorderRadius.circular(24)),
        child: Center(child: Text(item.symbol, style: const TextStyle(fontSize: 170, color: maroon)))),
      ),
      const SizedBox(height: 18),
      Text(item.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      Text(item.category, style: const TextStyle(color: maroon, fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      Text(item.detail, style: const TextStyle(fontSize: 16)),
      const SizedBox(height: 18),
      FilledButton.icon(onPressed: onToggle, icon: Icon(isFavorite ? Icons.favorite : Icons.favorite_border),
        label: Text(isFavorite ? 'पसंदीदा में सेव है' : 'पसंदीदा में सेव करें')),
      OutlinedButton.icon(onPressed: () => Share.share('${item.title}\\n${item.detail}\\nMehndi Magic AI'),
        icon: const Icon(Icons.share), label: const Text('डिज़ाइन शेयर करें')),
    ])),
  );
}

class FavoritesScreen extends StatelessWidget {
  final Set<String> favorites;
  final void Function(String) onToggle;
  const FavoritesScreen({super.key, required this.favorites, required this.onToggle});
  @override
  Widget build(BuildContext context) {
    final saved = designs.where((d) => favorites.contains(d.title)).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('मेरे पसंदीदा डिज़ाइन')),
      body: saved.isEmpty
        ? const Center(child: Text('अभी कोई डिज़ाइन सेव नहीं है ❤️'))
        : ListView.builder(itemCount: saved.length, itemBuilder: (_, i) {
          final d = saved[i];
          return ListTile(leading: Text(d.symbol, style: const TextStyle(fontSize: 32, color: maroon)),
            title: Text(d.title), subtitle: Text(d.category),
            trailing: IconButton(icon: const Icon(Icons.favorite, color: maroon), onPressed: () => onToggle(d.title)));
        }),
    );
  }
}
