# MehndiMagicAI — Android APK build (Hindi)

## इस ZIP में क्या है?
- मूल Flutter MVP source code
- GitHub Actions workflow: `.github/workflows/android-apk.yml`
- Workflow Android release APK को cloud runner पर build करके artifact के रूप में रखेगा।

## सिर्फ Android फोन से APK बनाने के चरण
1. GitHub पर अकाउंट बनाएं/लॉग इन करें: https://github.com
2. नया repository बनाएं, उदाहरण: `MehndiMagicAI`
3. इस ZIP को extract करके इसके अंदर की सभी फाइलें repository में upload करें। `.github/workflows/android-apk.yml` को भी उसी path पर रखें।
4. Repository में `Actions` tab खोलें और `Build Android APK` workflow चुनें।
5. `Run workflow` दबाएं। Build पूरा होने पर workflow run खोलें।
6. `Artifacts` में `MehndiMagicAI-Android-APK` डाउनलोड करें। ZIP artifact के अंदर `app-release.apk` होगा।
7. फोन में APK खोलें। यदि Android अनुमति मांगे, तो केवल अपने भरोसेमंद build के लिए browser/files app को “Install unknown apps” की अनुमति दें।

## महत्वपूर्ण सीमाएं
यह APK अभी मूल MVP ही होगा: demo design cards, search/category filter, favorites, photo picker और sharing।
यह workflow अपने-आप online booking, artist accounts, live availability, admin panel या Razorpay payments नहीं जोड़ता।
उनके लिए backend/database, authentication, booking status flow, secure server-side Razorpay order creation and payment verification, privacy policy, and testing अभी अलग से implement करने होंगे।

## सुरक्षा
- Razorpay API secret/key secret को Flutter app या GitHub source में hard-code न करें।
- Uploaded CSV/API keys को public repository में upload न करें। यदि कोई secret key कहीं public हो गई हो, उसे Razorpay dashboard से rotate/revoke करें।
- Production payments से पहले server-side signature verification और webhook verification अनिवार्य रखें।
