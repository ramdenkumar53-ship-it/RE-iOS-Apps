# Mehndi Magic AI — Android MVP

यह Flutter का शुरुआती स्रोत-कोड है। अभी यह डिज़ाइन कैटलॉग, खोज, श्रेणी फ़िल्टर, पसंदीदा डिज़ाइन, फोटो चुनना और शेयर करना देता है।

## ज़रूरी बात
- यह अभी APK नहीं है; यह ऐप का source project है।
- गैलरी में फिलहाल प्रतीकात्मक डेमो कार्ड हैं, वास्तविक डिज़ाइन चित्र नहीं।
- फोटो पर दिखने वाला मेहंदी चिह्न केवल demo overlay है; इसमें AI hand tracking नहीं है।
- AI generation, online bookings, payments और admin panel अभी शामिल नहीं हैं।

## मुफ़्त में APK बनाने के लिए
1. कंप्यूटर पर Flutter SDK और Android Studio इंस्टॉल करें।
2. इस फ़ोल्डर को खोलें।
3. टर्मिनल में चलाएँ:
   `flutter pub get`
   `flutter analyze`
   `flutter build apk --release`
4. APK यहाँ बनेगा:
   `build/app/outputs/flutter-apk/app-release.apk`

## Android मोबाइल पर
सिर्फ फोन से पूरा Flutter APK build करना कठिन हो सकता है। कंप्यूटर उपलब्ध न हो तो GitHub + cloud build workflow इस्तेमाल किया जा सकता है, लेकिन उसे अलग से configure करना होगा।

## अगले चरण
1. वास्तविक, उपयोग के लिए लाइसेंस प्राप्त मेहंदी डिज़ाइन चित्र जोड़ें।
2. फोटो editor में draggable/rotatable transparent overlay लागू करें।
3. परीक्षण के बाद privacy policy और Play Store requirements तैयार करें।
